import React, { useState } from 'react';
import { GLE_LOGO_URL } from '../constants';

interface LoginProps {
  onLogin: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Validate credentials: Gerson.gomez / 16926356
    // Case insensitive for username
    if (username.trim().toLowerCase() === 'gerson.gomez' && password.trim() === '16926356') {
      onLogin();
    } else {
      setError('Usuario o contraseña incorrectos.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#F3F4F6] font-sans p-4">
      <div className="w-full max-w-sm bg-white rounded-lg shadow-xl overflow-hidden border-t-4 border-gle-red animate-fade-in-up">
        {/* Header with Logo */}
        <div className="bg-[#111111] p-8 text-center">
          <img 
            src={GLE_LOGO_URL} 
            alt="GLE Colombia" 
            className="h-14 mx-auto object-contain"
          />
          <p className="text-gray-400 text-xs mt-3 tracking-[0.2em] uppercase font-light">Centro de Aplicaciones</p>
        </div>
        
        <div className="p-8">
          <h2 className="text-lg font-bold text-gray-800 text-center mb-6">Iniciar Sesión</h2>
          
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-gray-600 uppercase mb-1.5">Usuario</label>
              <input 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-gle-red focus:border-transparent transition-all placeholder-gray-400 bg-gray-50 focus:bg-white"
                placeholder="Ej: Gerson.gomez"
                autoFocus
              />
            </div>
            
            <div>
              <label className="block text-xs font-bold text-gray-600 uppercase mb-1.5">Contraseña</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-gle-red focus:border-transparent transition-all placeholder-gray-400 bg-gray-50 focus:bg-white"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <div className="text-red-600 text-xs bg-red-50 p-3 rounded-md border border-red-100 flex items-start">
                 <svg className="w-4 h-4 mr-2 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                 </svg>
                 {error}
              </div>
            )}

            <button 
              type="submit"
              className="w-full bg-gle-red text-white font-bold py-3 rounded hover:bg-[#b01327] transition-all duration-200 text-sm shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
            >
              INGRESAR
            </button>
          </form>
        </div>
        
        <div className="bg-gray-50 px-6 py-4 text-center border-t border-gray-100">
           <p className="text-[10px] text-gray-400">
             &copy; {new Date().getFullYear()} GLE Colombia - Todos los derechos reservados.
           </p>
        </div>
      </div>
    </div>
  );
};