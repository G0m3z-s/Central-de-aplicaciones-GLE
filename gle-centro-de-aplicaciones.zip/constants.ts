// Using the GLE logo URL provided in the context or a placeholder if needed.
// We will use an SVG representation or the hosted image for best results.
export const GLE_LOGO_URL = "https://www.glecolombia.com/wp-content/uploads/2022/12/Logo-GLE-Blanco.png";

export const STORAGE_KEY = 'gle_app_hub_data_v1';

export const COLORS = {
  primary: '#D81730',
  text: '#111111',
  muted: '#6B7280',
  bg: '#F3F4F6',
  white: '#FFFFFF'
};