import React, { useState, useEffect, useMemo } from 'react';
import { AppItem } from './types';
import { getApps, saveApps, exportData, importData } from './services/storageService';
import { Modal } from './components/Modal';
import { AppCard } from './components/AppCard';
import { AppForm } from './components/AppForm';
import { Button } from './components/Button';
import { Login } from './components/Login';
import { GLE_LOGO_URL } from './constants';

const App: React.FC = () => {
  // Auth State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);

  // App Data State
  // IMPORTANTE: Inicializamos el estado directamente desde localStorage.
  // Esto previene que se guarde un array vacío accidentalmente al cargar la página.
  const [apps, setApps] = useState<AppItem[]>(() => getApps());
  
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentApp, setCurrentApp] = useState<AppItem | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);

  useEffect(() => {
    // Check authentication on mount
    const authStatus = localStorage.getItem('gle_auth_token');
    if (authStatus === 'valid') {
      setIsAuthenticated(true);
    }
    // No necesitamos cargar getApps() aquí porque ya lo hicimos en el useState inicial
    setIsLoadingAuth(false);
  }, []);

  useEffect(() => {
    // Cada vez que 'apps' cambie, guardamos en localStorage.
    // Como inicializamos con getApps(), nunca sobreescribiremos con vacío al inicio.
    saveApps(apps);
  }, [apps]);

  const handleLogin = () => {
    localStorage.setItem('gle_auth_token', 'valid');
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    // Cierre de sesión inmediato.
    // Solo borramos el token de sesión.
    // NO tocamos la clave 'gle_app_hub_data_v1' donde están las apps.
    localStorage.removeItem('gle_auth_token');
    setIsAuthenticated(false);
    setSearchQuery(''); // Limpiamos el buscador visualmente
  };

  const handleAddApp = (data: { name: string; url: string; category: string }) => {
    if (editingId) {
      setApps(prev => prev.map(app => 
        app.id === editingId 
          ? { ...app, ...data } 
          : app
      ));
      setEditingId(null);
    } else {
      const newApp: AppItem = {
        id: crypto.randomUUID(),
        createdAt: Date.now(),
        ...data
      };
      setApps(prev => [newApp, ...prev]);
    }
  };

  const handleDelete = (id: string) => {
    if (window.confirm('¿Seguro que deseas eliminar esta aplicación?')) {
      setApps(prev => prev.filter(app => app.id !== id));
    }
  };

  const handleEdit = (app: AppItem) => {
    setEditingId(app.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const importedApps = await importData(file);
        if (window.confirm(`Se encontraron ${importedApps.length} aplicaciones. ¿Deseas reemplazar tu lista actual?`)) {
          setApps(importedApps);
        }
      } catch (err) {
        alert("Error al importar el archivo JSON. Verifica el formato.");
      }
      e.target.value = '';
    }
  };

  const filteredApps = useMemo(() => {
    const lowerQuery = searchQuery.toLowerCase();
    return apps.filter(app => 
      app.name.toLowerCase().includes(lowerQuery) || 
      app.url.toLowerCase().includes(lowerQuery) ||
      app.category.toLowerCase().includes(lowerQuery)
    );
  }, [apps, searchQuery]);

  const editingApp = useMemo(() => 
    apps.find(a => a.id === editingId), 
  [apps, editingId]);

  // Render Logic
  if (isLoadingAuth) {
    return null; // Or a loading spinner
  }

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-[#F3F4F6] pb-20 font-sans text-gray-800 animate-fade-in-up">
      
      {/* Header Corporativo */}
      <header className="bg-[#111111] text-white shadow-lg sticky top-0 z-40 border-b-4 border-gle-red">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
             <div className="flex-shrink-0">
               <img 
                 src={GLE_LOGO_URL} 
                 alt="GLE Logo" 
                 className="h-10 md:h-12 w-auto object-contain"
               />
             </div>
             <div className="hidden md:block h-8 w-px bg-gray-700 mx-2"></div>
             <h1 className="text-lg md:text-xl font-light tracking-wide text-gray-100 hidden sm:block">
               Centro de Aplicaciones
             </h1>
          </div>

          <div className="flex items-center gap-4">
             {/* Search Bar */}
             <div className="relative hidden md:block w-64">
               <input 
                 type="text" 
                 placeholder="Buscar aplicación..." 
                 className="w-full bg-gray-800 text-sm text-white border border-gray-700 rounded-full px-4 py-1.5 focus:outline-none focus:ring-1 focus:ring-gle-red focus:border-gle-red placeholder-gray-500"
                 value={searchQuery}
                 onChange={(e) => setSearchQuery(e.target.value)}
               />
               <svg className="w-4 h-4 text-gray-500 absolute right-3 top-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
               </svg>
             </div>

             {/* Logout Button */}
             <button 
               onClick={handleLogout}
               className="flex items-center gap-2 text-xs text-gray-400 hover:text-white transition-colors border border-gray-700 hover:border-gray-500 rounded-full px-3 py-1.5 bg-gray-800 hover:bg-gray-700"
               title="Cerrar Sesión"
             >
               <span className="hidden sm:inline font-medium">Salir</span>
               <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
               </svg>
             </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Mobile Search */}
        <div className="md:hidden mb-6">
           <input 
             type="text" 
             placeholder="Buscar aplicación..." 
             className="w-full bg-white text-sm border-gray-300 rounded-md px-4 py-3 shadow-sm focus:ring-gle-red focus:border-gle-red"
             value={searchQuery}
             onChange={(e) => setSearchQuery(e.target.value)}
           />
        </div>

        {/* Action Bar / Stats */}
        <div className="flex justify-between items-center mb-6">
           <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
             Total: <span className="text-gray-900">{filteredApps.length}</span> Aplicaciones
           </p>
           
           <div className="flex gap-2">
             <label className="cursor-pointer inline-flex items-center justify-center px-3 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50">
               <svg className="w-3.5 h-3.5 mr-1.5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
               </svg>
               Importar JSON
               <input type="file" accept=".json" className="hidden" onChange={handleImport} />
             </label>
             <button 
                onClick={() => exportData(apps)}
                className="inline-flex items-center justify-center px-3 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50"
             >
               <svg className="w-3.5 h-3.5 mr-1.5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
               </svg>
               Exportar
             </button>
           </div>
        </div>

        {/* Form Section */}
        <AppForm 
          onSubmit={handleAddApp} 
          initialData={editingApp}
          isEditing={!!editingId}
          onCancel={() => setEditingId(null)}
        />

        {/* Grid */}
        {filteredApps.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filteredApps.map(app => (
              <AppCard 
                key={app.id} 
                app={app} 
                onOpen={(a) => window.open(a.url, '_blank', 'noopener,noreferrer')}
                onPreview={(a) => {
                  setCurrentApp(a);
                  setIsModalOpen(true);
                }}
                onDelete={handleDelete}
                onEdit={handleEdit}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-lg border border-dashed border-gray-300">
            <svg className="mx-auto h-12 w-12 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No hay aplicaciones</h3>
            <p className="mt-1 text-sm text-gray-500">Agrega una nueva aplicación usando el formulario de arriba.</p>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
           <p className="text-xs text-gray-400">
             &copy; {new Date().getFullYear()} GLE Colombia. Todos los derechos reservados.
           </p>
           <p className="text-[10px] text-gray-300">
             Internal Dashboard v1.1
           </p>
        </div>
      </footer>

      {/* Modal */}
      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        app={currentApp}
      />
    </div>
  );
};

export default App;